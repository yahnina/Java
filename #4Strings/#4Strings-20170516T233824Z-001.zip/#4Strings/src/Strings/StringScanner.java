package Strings;


import java.util.Scanner;

/**
 * Created by Lena on 19.03.2017.
 */
public class StringScanner {
    static Scanner reader= new Scanner(System.in);




}
